<?php include("funs.php"); 
	require_once 'config_files.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>WEB-BASED INTERACTIVE DASHBOARD OF COVID-19 CASES</title>
        <link rel = "icon" href =
        "images/logo.png"
        type = "image/x-icon">
        <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="css/isolation_wards.css">


<!-- Bootstrap CSS -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>

<body>
<?php require_once "navbar.php"; ?>
<?php



         $con=mysqli_connect($servername,$uname,$pass,$dbname);
         $getid=$_GET['id'];



        $query="select * from isolation_ward where isolation_ward_id='$getid';";
        $result=mysqli_query($con,$query);

   while($row=mysqli_fetch_array($result)){

              $isolation_ward_id=$row['isolation_ward_id'];
              $isolation_ward_name=$row['isolation_ward_name'];
              $capacity=$row['capacity'];
              $city=$row['city'];
              $province=$row['province'];
              $lat=$row['lat'];
              $lng=$row['lng'];
             
}
            ?>
    <section id="updateIsolationWards" style="margin-top:60px;">
     <div class ="container">
       <h1>Update Isolation Ward Data</h1>
     
    <br>
    <div class="main" style="margin-top:-34px;">

              <div class="card-body" >

        <form class="form-group" action="fun_update_Isolation_Wards.php" method="post">
          <label>ID:</label><br>
          <input type="text" name="id" class="form-control" value= "<?php echo $isolation_ward_id ?>" readonly ><br>

     
          <label>Hospital Name:</label><br>
          <input type="text" name="hospital_name" class="form-control"  value= "<?php echo $isolation_ward_name ?>" ><br>
          <label>Capacity</label><br>
          <input type="text" name="capacity" class="form-control"  value= "<?php echo $capacity ?>" ><br>
          <label>City:</label><br>
          <input type="text" name="city" class="form-control"  value= "<?php echo $city ?>" ><br>
          <label>Provience:</label><br>
          <input type="text" name="provience" class="form-control"  value= "<?php echo $province ?>" ><br>
			<label>Lat:</label><br>
          <input type="text" name="lat" class="form-control"  value= "<?php echo $lat ?>" ><br>
			<label>Long:</label><br>
          <input type="text" name="lng" class="form-control"  value= "<?php echo $lng ?>" ><br>
            <input type="submit" class="btn btn-primary" name="iso_submit" value="Update Isolation Ward">
        </form>
            </div>
          </div>
    </div>
    <div/>

</section>

  </body>

  </html>
