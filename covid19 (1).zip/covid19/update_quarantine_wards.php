<?php include("funs.php"); 
	require_once 'config_files.php';
?><!DOCTYPE html>
<html>
<head>
<title>WEB-BASED INTERACTIVE DASHBOARD OF COVID-19 CASES</title>
        <link rel = "icon" href =
        "images/logo.png"
        type = "image/x-icon">
        <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="css/isolation_wards.css">


<!-- Bootstrap CSS -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>

<body>
<?php require_once "navbar.php"; ?>
<?php



         $con=mysqli_connect($servername,$uname,$pass,$dbname);
         $getid=$_GET['id'];



        $query="select * from quarantine_ward where quarantine_ward_id='$getid';";
        $result=mysqli_query($con,$query);

   while($row=mysqli_fetch_array($result)){

              $quarantine_ward_id=$row['quarantine_ward_id'];
              $quarantine_ward_name=$row['quarantine_ward_name'];
              $capacity=$row['capacity'];
              $city=$row['city'];
              $province=$row['province'];
              $phn_num=$row['phn_num'];
              $head_name=$row['head_name'];
              $lat=$row['lat'];
              $lng=$row['lng'];
             
}
            ?>

    <section id="updateQuarantineWards" style="margin-top:60px;">
     <div class ="container">
       <h1>Update Quarantine Ward Data</h1>
       <hr/>
       <br>
     
    <div class="main" style="margin-top:-34px;">

              <div class="card-body" >

        <form class="form-group" action="fun_update_quarantine_Wards.php" method="post">
          <label>ID:</label><br>
          <input type="text" name="id" class="form-control" value= "<?php echo $quarantine_ward_id ?>" readonly ><br>

          <label>Quarantine Center Name:</label><br>
          <input type="text" name="quarantine_name" class="form-control" value= "<?php echo $quarantine_ward_name ?>"><br>
          <label>Capacity</label><br>
          <input type="text" name="capacity" class="form-control" value= "<?php echo $capacity ?>"><br>
          <label>City:</label><br>
          <input type="text" name="city" class="form-control" value= "<?php echo $city ?>"><br>
          <label>Provience:</label><br>
          <input type="text" name="province" class="form-control" value= "<?php echo $province ?>"><br>
          <label>Phone Number:</label><br>
          <input type="text" name="phn_num" class="form-control" value= "<?php echo $phn_num ?>"><br>
          <label>Head Name:</label><br>
          <input type="text" name="head_name" class="form-control" value= "<?php echo $head_name ?>"><br>
<label>Lat:</label><br>
          <input type="text" name="lat" class="form-control"  value= "<?php echo $lat ?>" ><br>
			<label>Long:</label><br>
          <input type="text" name="lng" class="form-control"  value= "<?php echo $lng ?>" ><br>
            <input type="submit" class="btn btn-primary" name="qur_submit" value="Update Quarantine Ward">
        </form>
            </div>
          </div>
    </div>
    <div/>

</section>

  </body>

  </html>
