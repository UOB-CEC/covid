<?php

$con=mysqli_connect("localhost","root","root","covid_19_dbms");
if($con)
{
	echo"Connection OK";
}
else
{
	echo"Connection failed";
}


	$hname=$_POST['hospital_name'];
	$cap=$_POST['capacity'];
	$city=$_POST['city'];
	$prov=$_POST['provience'];
	$lat=$_POST['lat'];
	$lng=$_POST['lng'];
if(isset($_POST['iso_submit']))
{

	$quary="insert into isolation_ward(isolation_ward_name,capacity,city,province,lat,lng)
	Values ('$hname','$cap','$city','$prov','$lat','$lng')";

	$result=mysqli_query($con,$quary);
	if($result)
	{
		echo"<script>alert('Data saved Successfully')</script>";
    echo"<script>window.open('search_isolation_wards.php','_self')</script>";
	}
}

?>
