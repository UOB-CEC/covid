<?php

error_reporting(E_ALL);
/*
define('servername','localhost');
define('uname','root');
define('pass','root');
define('dbname','covid_19_dbms');
define('apimapkey','AIzaSyCT1ChZ5tdPLFABVd_nn8jJ1ZrPRKqiApw');
*/
		
		$uname="root";
        $pass="root";
        $servername="localhost";
        $dbname="covid_19_dbms";
		
	$con=mysqli_connect($servername,$uname,$pass,$dbname);
$apimapkey="AIzaSyCT1ChZ5tdPLFABVd_nn8jJ1ZrPRKqiApw";
	/*
		global $uname;
		global $pass;
		global $servername;
		global $dbname;
		$con=mysqli_connect($servername,$uname,$pass,$dbname);

		
*/
// mysqli_connect($servername,$uname,$pass,$dbname);
//include_once 'config_files.php';
// $con=mysqli_connect($servername,$uname,$pass,$dbname);
?>